"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.news = exports.check = void 0;
const axios_1 = require("axios");
const dayjs = require("dayjs");
const customParseFormat = require("dayjs/plugin/customParseFormat");
const isBetween = require("dayjs/plugin/isBetween");
dayjs.extend(customParseFormat);
dayjs.extend(isBetween);
const formatString = "ddd, DD MMM YYYY HH:mm:ss Z";
const check = (event, context) => __awaiter(void 0, void 0, void 0, function* () {
    return {
        statusCode: 200,
        body: JSON.stringify({
            message: "Hello lambda!",
        }),
    };
});
exports.check = check;
function getNews(keyword, idx) {
    return __awaiter(this, void 0, void 0, function* () {
        return yield (0, axios_1.default)({
            method: 'get',
            url: 'https://openapi.naver.com/v1/search/news.json',
            params: {
                query: keyword,
                display: 100,
                start: idx,
                sort: 'date'
            },
            headers: {
                "X-Naver-Client-Id": process.env.NAVER_NEWS_CLIENT_ID,
                "X-Naver-Client-Secret": process.env.NAVER_NEWS_SECRET_KEY
            }
        });
    });
}
// @ts-ignore
function shortUrl(urlString) {
    return __awaiter(this, void 0, void 0, function* () {
        return yield (0, axios_1.default)({
            method: 'get',
            url: 'https://openapi.naver.com/v1/util/shorturl',
            params: {
                url: urlString
            },
            headers: {
                "X-Naver-Client-Id": process.env.NAVER_URL_CLIENT_ID,
                "X-Naver-Client-Secret": process.env.NAVER_URL_SECRET_KEY
            }
        }).then(v => {
            if (v.data.code === "200") {
                return v.data.result.url;
            }
            else {
                return "";
            }
        });
    });
}
const news = (event, context) => __awaiter(void 0, void 0, void 0, function* () {
    console.log('call news');
    const queryStringParameters = event.queryStringParameters;
    const keyword = event.queryStringParameters['keyword'];
    const previousDate = Number(queryStringParameters['previousDate']);
    const toDate = dayjs();
    const previous = toDate.subtract(previousDate, 'day');
    // const endDate = dayjs(event.pathParameters.endDate);
    try {
        let arr = [];
        let idx = 1;
        while (true) {
            let response = yield getNews(keyword, idx);
            for (let i = 0; i < response.data.items.length; i++) {
                const t = dayjs(response.data.items[i].pubDate, { format: formatString }).format('YYYY-MM-DD');
                if (dayjs(t).isBetween(toDate, previous, null, '[]')) {
                    // response.data.items[i]['link'] = await shortUrl(response.data.items[i]['originallink']);
                    arr.push(response.data.items[i]);
                }
                else {
                    idx = -1;
                    break;
                }
            }
            if (idx === -1)
                break;
            idx += 100;
        }
        // @ts-ignore
        return keyword;
    }
    catch (e) {
        console.log(e);
        return "server error";
    }
});
exports.news = news;
function template(keyword, period, arr) {
    let str = `※ ${period} 주요기사(인천세관 홍보계)
` + '\n' + '\n' +
        `- ${keyword} -`;
    arr.forEach(v => {
        str += v['title'] + '\n';
        str += v['link'] + '\n';
        str += '\n';
    });
    return str;
}
//# sourceMappingURL=handler.js.map